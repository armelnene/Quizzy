/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.google.gtv.ws;

import com.google.gson.Gson;
import com.google.gtv.Answer;
import com.google.gtv.Question;
import com.google.gtv.Video;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;

/**
 * REST Web Service
 *
 * @author Armel
 */
@Path("/videos")
public class VideoQuizWS {

    @Context
    private UriInfo context;
    private List<Video> videos;

    /**
     * Retrieves representation of an instance of com.google.gtv.ws.VideoQuizWS
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("application/json")
    public String getVideoQuiz() {
        init();
        Gson gson = new Gson();

        return gson.toJson(videos);
    }

    private void init() {
        if (videos == null) {
            final Video video = new Video("ww.google.com", new Question("what is the capital", new ArrayList<Answer>() {

                {
                    add(new Answer("what", Boolean.FALSE));
                    add(new Answer("who", Boolean.FALSE));
                    add(new Answer("when", Boolean.TRUE));
                }
            }));

            final Video video2 = new Video("ww.google.com", new Question("what is the world", new ArrayList<Answer>() {

                {
                    add(new Answer("what", Boolean.FALSE));
                    add(new Answer("who", Boolean.TRUE));
                    add(new Answer("when", Boolean.FALSE));
                }
            }));

            this.videos = new ArrayList<Video>(new ArrayList<Video>() {

                {
                    add(video);
                    add(video2);
                }
            });
        }


    }
}
